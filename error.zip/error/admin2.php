<?php
$con=mysqli_connect("localhost","root","root","system_problem");
// date_default_timezone_set('Asia/Kolkata');
// $solve_time=date('d-m-Y H:i')
// $solve_time=NOW();

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="bootstrap.min.js"></script>
	<script type="text/JavaScript">
         <!--
            function AutoRefresh( t ) {
               setTimeout("location.reload(true);", t);
            }
         //-->
      </script>
</head>
<body onload="JavaScript:AutoRefresh(50000000);">
<!-- <table align="center">
	<form method="post" action="">
		<tr>
			<td>Sr.Name</td><td><input type="text" name="sr_name" style="height: 30px; width: 200px;"></td>
		</tr>
		<tr>
			<td>Problem</td><td><textarea name="problem" style="height: 100px; width: 200px;"></textarea></td>
			
		</tr>
		<tr>
			<td colspan="3" align="center"><input type="submit" name="s" value="Send"></td>
		</tr>
	</form>
</table> -->
<?php
	// if(isset($_POST["s"]))
	// {
	// 	extract($_POST);

	// 	$qry=mysqli_query($con,"INSERT INTO `problem`(`sr_name`, `problem`, `c_time`) VALUES ('$sr_name','$problem','$c_time')");
	// 	if($qry)
	// 	{
	// 		echo "<script>alert('Send Sucess')</script>";
	// 	}
	// }
?>

<hr>
<table  class="table table-bordered">
	<tr>
		<td style="width: 100px;" align="center">Sr.Name</td>
		<td style="width: 700px;" align="center">Problem</td>
		<td align="center">Time</td>
		<td align="center">Solve Time</td>
		<td align="center">Reply</td>
		<td align="center">Admin Reply</td>
	</tr>
	<?php
	$qry1=mysqli_query($con,"select * from problem order by id desc");
	while($row=mysqli_fetch_array($qry1))
	{
		extract($row);
	?>
	<tr>
		<td align="center"><?php echo $sr_name ?></td>
		<td align="center"><?php echo $problem ?></td>
		<td align="center"><?php echo $c_time ?></td>
		<td align="center"><?php echo $solve_time ?></td>
		<td align="center"><?php echo $solve; ?></td>
	 

    <form method="post" action="">
	       <td><input type="text" name="admin_reply" value="<?php echo $admin_reply; ?>" style="width: 100px;">
		       <input type="hidden" name="getid" value="<?= $row['id'] ?>" >
		       <!-- <input type="submit" name="admin" value="Update"> -->
		       <button type="submit" class="btn btn-danger" name="admin">Update</button> 
	      </td>
    </form>
	</tr>
	<?php
	}
	?>






<?php

if(isset($_POST["admin"]))
{
  extract($_POST);

  $qry=mysqli_query($con, "update problem set admin_reply='$admin_reply' where id='$getid'");
  echo "<script>alert('update')</script>";
  echo "<script>window.open('admin2.php','_self')</script>";
}

?>
</table>
</body>
</html>