<?php
echo $id=$_REQUEST["id"];

?>