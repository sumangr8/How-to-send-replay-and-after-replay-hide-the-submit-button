<?php
$con=mysqli_connect("localhost","root","","system_problem");
date_default_timezone_set('Asia/Kolkata');
$c_time=date('d-m-Y H:i')
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table align="center">
	<form method="post" action="">
		<tr>
			<td>Sr.Name</td><td><input type="text" name="sr_name" style="height: 30px; width: 200px;"></td>
		</tr>
		<tr>
			<td>Problem</td><td><textarea name="problem" style="height: 100px; width: 200px;"></textarea></td>
			
		</tr>
		<tr>
			<td colspan="3" align="center"><input type="submit" name="s" value="Send"></td>
		</tr>
	</form>
</table>
<?php
	if(isset($_POST["s"]))
	{
		extract($_POST);

		$qry=mysqli_query($con,"INSERT INTO `problem`(`sr_name`, `problem`, `c_time`) VALUES ('$sr_name','$problem','$c_time')");
		if($qry)
		{
			echo "<script>alert('Send Sucess')</script>";
		}
	}
?>

<hr>
<table border="1" width="1200">
	<tr>
		<td style="width: 100px;">Sr.Name</td>
		<td style="width: 900px;">Problem</td>
		<td>Reply</td>
	</tr>
	<?php
	$qry1=mysqli_query($con,"select * from problem");
	while($row=mysqli_fetch_array($qry1))
	{
		extract($row);
	?>
	<tr>
		<td><?php echo $sr_name ?></td>
		<td><?php echo $problem ?></td>

	 <form method="post" action="">
	       <td><input type="text" name="solve" value="<?php echo $solve; ?>" style="width: 100px;">
		       <input type="hidden" name="getid" value="<?= $row['id'] ?>" >
		       <input type="submit" name="f" value="Update"> 
	      </td>
    </form>
	</tr>
	<?php
	}
	?>


<?php

if(isset($_POST["f"]))
{
  extract($_POST);

  $qry=mysqli_query($con, "update problem set solve='$solve' where id='$getid'");
  echo "<script>alert('update')</script>";
  echo "<script>window.open('index.php','_self')</script>";
}

?>
</table>
</body>
</html>