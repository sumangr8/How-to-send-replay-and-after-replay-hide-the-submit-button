<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container" style="text-align: center;">
<table class="table" align="center">
	<form method="post" action="">
		<tr>
			<td>User Id:-<input type="text" name="name"></td>
		</tr>
		<tr>
			<td>Password:-<input type="password" name="password"></td>
		</tr>
		<tr>
			<td><input type="submit" name="s" value="Login"></td>
		</tr>
	</form>
</table>
</div>
<?php
	if(isset($_POST["s"]))
	{
		extract($_POST);
		if($name=='theequicom' and $password=='theequicomgr8')
		{
			header("location:admin2.php");
		}
		else
		{
			echo "Wrong Password";
		}
	}
?>
</body>
</html>